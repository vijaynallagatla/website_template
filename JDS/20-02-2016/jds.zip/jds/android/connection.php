<?php
	require_once('config.php');
	
	class DB_Connection{
		private $connect;
		
		function __construct(){
			$this->connect=mysqli_connect(sql_host,sql_username,sql_password,sql_db)or die("Error in connection to database");	
		}
		
		function get_connection(){
			return $this->connect;
		}
	}

?>