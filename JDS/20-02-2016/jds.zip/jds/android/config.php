<?php
define('sql_host','localhost');
define('sql_username','root');
define('sql_password','');
define('sql_db','jds');
?>