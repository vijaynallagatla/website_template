<?php
	require_once('connection.php');
	header("Content-Type: application/json");
	
	class User{
		
		private $db;
		private $connection;
		function __construct(){
			$this->db=new DB_Connection();
			$this->connection=$this->db->get_connection();
		}
		
		function does_user_exist($email,$password){
			$query="SELECT * FROM USER WHERE EMAIL='$email' AND PASSWORD='$password'";
			$result=mysqli_query($this->connection,$query);
			if(mysqli_num_rows($result)>0){
				$json['login_state']="success";
				
				//elements
				$cursor=mysqli_fetch_assoc($result);
				
				$json['name']=$cursor['name'];
				$json['ph_no']=$cursor['ph_no'];
				$json['address']=$cursor['address'];
				$json['district']=$cursor['district'];
				$json['state']=$cursor['state'];
				$json['pincode']=$cursor['pincode'];
				$json['gender']=$cursor['gender'];
				$json['dob']=$cursor['dob'];
				
			}else{
				$json['login_state']="fail";
				$json['error_message']="Please enter the valid email and password";
			}
			
			echo json_encode($json);
			 
		}
	}
	
	$user=new User();
	if(isset($_POST['email'],$_POST['password'])){
		$email=$_POST['email'];
		$password=$_POST['password'];
		
		if(!empty($email) && !empty($password)){
			$user->does_user_exist($email,$password);
		}else{
			$json['login_state']="fail";
			$json['error_message']="Please enter the Email and Password";
			
			echo json_encode($json);
		}
	}

?>