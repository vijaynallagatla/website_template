package com.pastelloid.vijay.jds.news;


import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.pastelloid.vijay.jds.MainActivity;
import com.squareup.picasso.Picasso;

import static com.facebook.FacebookSdk.getApplicationContext;
import static com.pastelloid.vijay.jds.R.*;
import static java.lang.System.load;
import static java.security.AccessController.getContext;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder> {

    private String[] titles;

    private String[] details;

    private String[] images;

    RecyclerAdapter(String[] titles,String[] details,String[] image){
        this.titles=titles;
        this.details=details;
        this.images=image;
    }

    class ViewHolder extends RecyclerView.ViewHolder{

        public int currentItem;
        public ImageView itemImage;
        public TextView itemTitle;
        public TextView itemDetail;
        public RelativeLayout layout;

        public ViewHolder(View itemView) {
            super(itemView);
            layout=(RelativeLayout)itemView.findViewById(id.news_Layout);
            itemImage = (ImageView)itemView.findViewById(id.news_img);
            itemTitle = (TextView)itemView.findViewById(id.news_title);
            itemDetail =
                    (TextView)itemView.findViewById(id.news_body);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    int position = getAdapterPosition();


                }
            });
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(layout.news_card, viewGroup, false);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        viewHolder.itemTitle.setText(titles[i]);
        viewHolder.itemDetail.setText(details[i]);
        viewHolder.itemImage.setImageResource(drawable.jds_logo);
        Log.d("Image",images[i]);
        if(images[i]=="null"){

        }else{
            viewHolder.itemImage.setVisibility(View.VISIBLE);
            Picasso.with(getApplicationContext()).load(images[i]).into(viewHolder.itemImage);
        }
    }

    @Override
    public int getItemCount() {
        return titles.length;
    }
}