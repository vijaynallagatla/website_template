package com.pastelloid.vijay.jds.dummy;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;

import com.pastelloid.vijay.jds.R;

public class DrawerManifestos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drawer_manifestos);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        WebView aboutjds=(WebView) findViewById(R.id.drawer_manifestos);
        WebSettings webSettings = aboutjds.getSettings();
        webSettings.setJavaScriptEnabled(true);
        aboutjds.loadUrl("https://docs.google.com/viewerng/viewer?url=http://jds.ind.in/wp-content/uploads/2013/04/KARNATAKA-ENGLISH.pdf");

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }



}
