package com.pastelloid.vijay.jds.news;

import android.content.Context;


import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import com.pastelloid.vijay.jds.R;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;



public class NewsFragment extends Fragment {

    public NewsDBHandler newsDBHandler;
    public RecyclerView recyclerView;
    public RecyclerView.LayoutManager layoutManager;
    public RecyclerView.Adapter adapter;
    public StringRequest hostRequest;
    public RequestQueue requestQueue;
    private SwipeRefreshLayout swipeRefreshLayout;
    private static String URL ;
    View view;

    public NewsFragment() {
        // Required empty public constructor
    }


    public static NewsFragment newInstance(int position) {
        NewsFragment fragment = new NewsFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        newsDBHandler=new NewsDBHandler(this.getContext());

        URL=getString(R.string.host_url);
        URL+="user_news.php";

        final int lastId=newsDBHandler.getLastID();

        Log.d("ID:",Integer.toString(lastId));
        requestQueue=Volley.newRequestQueue(getContext());
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat mdformat = new SimpleDateFormat("dd / MM / yyyy ");
        String strDate = mdformat.format(calendar.getTime());

        if(lastId==0) {

            if (newsDBHandler.insertNews(1, strDate, "10:00 AM", "Janata Dal(Secular)","Welcome to Janata Dal(Secular)", "http://pastelloid.com/jds/android/images/party-symbol.jpg"))
                Log.d("News_Data_Insert", "Success");
            else
                Log.d("News_Data_Insert", "Failure");
        }else {

          displayData();
        }

           }

    public void displayData(){
        hostRequest= new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    Log.i("JSON",response);
                    JSONObject json=new JSONObject();
                    JSONArray jsonArray=new JSONArray(response);
                    json=jsonArray.getJSONObject(0);
                    Log.d("NewsState",json.getString("news_status"));
                    boolean news_status=json.getBoolean("news_status");

                    if(news_status){
                        for(int i=1;i<jsonArray.length();i++){
                            json=jsonArray.getJSONObject(i);
                            int id=json.getInt("id");
                            String title=json.getString("title");
                            String context=json.getString("context");
                            String pub_date=json.getString("pub_date");
                            String pub_time=json.getString("pub_time");
                            String img_url=json.getString("img_url");
                            newsDBHandler.insertNews(id,pub_date,pub_time,title,context,img_url);
                        }
                    }else{

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.d("Vogella:","Error ");
                }
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
               // Log.d("Error Response : ",error.getMessage());
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                HashMap<String, String> hashMap = new HashMap<String, String>();
                int lastId=newsDBHandler.getLastID();
                Log.d("GetParam",Integer.toString(lastId));
                hashMap.put("news_id",Integer.toString(lastId) );
                return hashMap;
            }
        };
        requestQueue.add(hostRequest);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       view =inflater.inflate(R.layout.fragment_news, container, false);
     //   ListView newsView=(ListView) view.findViewById(R.id.newsView);

        swipeRefreshLayout=(SwipeRefreshLayout)view.findViewById(R.id.news_swipeView);
        swipeRefreshLayout.setColorSchemeColors(getResources().getColor(android.R.color.holo_blue_dark),getResources().getColor(android.R.color.holo_blue_light),getResources().getColor(android.R.color.holo_green_light),getResources().getColor(android.R.color.holo_green_dark));
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                swipeRefreshLayout.setRefreshing(true);
                Log.d("Swipe","Refreshing News");
                (new Handler()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        swipeRefreshLayout.setRefreshing(false);

                        //   ListView newsView=(ListView) view.findViewById(R.id.newsView);

                        displayData();

                    }
                },3000);
            }
        });


        displayData();
        databaseCards(view);
        return view;
    }

    public void databaseCards(View view){
        recyclerView=(RecyclerView)view.findViewById(R.id.news_recycler_view);

        layoutManager=new LinearLayoutManager(this.getContext());
        recyclerView.setLayoutManager(layoutManager);

        NewsDBHandler db=new NewsDBHandler(this.getContext());
        long newsCount=db.getNewsCount();
        Cursor cursor=db.getAllData();

        cursor.moveToFirst();

        ArrayList<String> titles = new ArrayList<String>();
        ArrayList<String> images = new ArrayList<String>();
        ArrayList<String> body = new ArrayList<String>();
        while(!cursor.isAfterLast()) {
            titles.add(cursor.getString(3));
            images.add(cursor.getString(4));
            body.add(cursor.getString(5));
            cursor.moveToNext();
        }
        cursor.close();
        String[] title= titles.toArray(new String[titles.size()]);
        String[] image=images.toArray(new String[images.size()]);
        String[] content=body.toArray(new String[body.size()]);

        adapter=new RecyclerAdapter(title,content,image);
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();

    }

}
