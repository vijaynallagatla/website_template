package com.pastelloid.vijay.jds;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessaging;
import com.pastelloid.vijay.jds.login.LoginActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Registration extends AppCompatActivity {

    //All Fields
    EditText reg_email;
    EditText reg_password;
    EditText reg_dob;
    EditText reg_address;
    EditText reg_district;
    EditText reg_state;
    EditText reg_pincode;
    EditText reg_name;
    EditText reg_phNo;

    //Vogella Request Queue
    private RequestQueue requestQueue;
    private static String URL;
    private StringRequest stringRequest;
    private String deviceID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        URL=getString(R.string.host_url);
        URL+="user_registration.php";

        reg_email=(EditText)findViewById(R.id.reg_email);
        reg_password=(EditText)findViewById(R.id.reg_password);
        reg_name=(EditText)findViewById(R.id.reg_name);
        reg_address=(EditText)findViewById(R.id.reg_address);
        reg_district=(EditText)findViewById(R.id.reg_district);
        reg_state=(EditText)findViewById(R.id.reg_state);
        reg_pincode=(EditText)findViewById(R.id.reg_postalcode);
        reg_phNo=(EditText)findViewById(R.id.reg_phNo);

        FirebaseMessaging.getInstance().subscribeToTopic("JDS");
        deviceID = FirebaseInstanceId.getInstance().getToken();

        requestQueue = Volley.newRequestQueue(this);
    }

    public void registerToJDS(View view){

        stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject json = new JSONObject(response);

                    String state = json.getString("reg_state");
                    if (state.equals("success")) {
                        Toast.makeText(getApplicationContext(), "welcome "+reg_name.getText().toString(), Toast.LENGTH_SHORT).show();
                        SharedPreferences sharedPref = getSharedPreferences("com.pastelloid.vijay.jds.login", Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPref.edit();
                        editor.putString("login_state", "true");
                        editor.putString("email", reg_email.getText().toString());
                        editor.putString("username", reg_name.getText().toString());
                        editor.putString("gender", "Male");
                        editor.putString("dob", "04/05/92");
                        editor.putString("district", reg_district.getText().toString());
                        editor.putString("address", reg_address.getText().toString());
                        editor.putString("state", reg_state.getText().toString());
                        editor.putString("pincode", reg_pincode.getText().toString());
                        editor.putString("contactnumber", reg_phNo.getText().toString());
                        editor.commit();
                        startActivity(new Intent(getApplicationContext(), MainActivity.class));
                        finish();
                    } else {
                        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                        Toast.makeText(getApplicationContext(), "Enter valid email and password" + json.getString("login_state"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "Error Response : "+error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<String, String>();
                hashMap.put("email", reg_email.getText().toString());
                hashMap.put("password", reg_password.getText().toString());
                hashMap.put("name", reg_name.getText().toString());
                hashMap.put("ph_no", reg_phNo.getText().toString());
                hashMap.put("address",reg_address.getText().toString());
                hashMap.put("district", reg_district.getText().toString());
                hashMap.put("state", reg_state.getText().toString());
                hashMap.put("pincode", reg_pincode.getText().toString());
                hashMap.put("gender", "Male");
                hashMap.put("dob", "04/05/92");
                hashMap.put("deviceid", deviceID);
                return hashMap;
            }
        };
        requestQueue.add(stringRequest);
    }
}
