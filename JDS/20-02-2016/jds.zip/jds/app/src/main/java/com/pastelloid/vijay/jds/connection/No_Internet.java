package com.pastelloid.vijay.jds.connection;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.pastelloid.vijay.jds.login.LoginActivity;
import com.pastelloid.vijay.jds.R;

import java.net.InetAddress;

public class No_Internet extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(isInternetAvailable())
        setContentView(R.layout.activity_no__internet);
        else{
            Intent loginActivity=new Intent(this,LoginActivity.class);
            startActivity(loginActivity);
        }
    }

    public boolean isInternetAvailable() {
        try {
            InetAddress ipAddr = InetAddress.getByName("google.com"); //You can replace it with your name
            return !ipAddr.equals("");

        } catch (Exception e) {
            return false;
        }

    }

}
