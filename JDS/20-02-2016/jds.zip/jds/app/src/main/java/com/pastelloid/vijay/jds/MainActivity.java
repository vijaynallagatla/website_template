package com.pastelloid.vijay.jds;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.nfc.Tag;
import android.os.Bundle;
import android.provider.Settings;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ActionProvider;
import android.support.v4.view.ViewPager;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.ShareActionProvider;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;

import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.appindexing.Thing;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessaging;
import com.pastelloid.vijay.jds.dummy.DrawerAboutJDS;
import com.pastelloid.vijay.jds.dummy.DrawerContribution;
import com.pastelloid.vijay.jds.dummy.DrawerElectedMembers;
import com.pastelloid.vijay.jds.dummy.DrawerInfo;
import com.pastelloid.vijay.jds.dummy.DrawerManifestos;
import com.pastelloid.vijay.jds.dummy.DrawerMediaCenter;
import com.pastelloid.vijay.jds.dummy.DrawerOurLeadership;
import com.pastelloid.vijay.jds.dummy.DrawerSettings;
import com.pastelloid.vijay.jds.facebook.FaceboookFragment;
import com.pastelloid.vijay.jds.login.LoginActivity;
import com.pastelloid.vijay.jds.news.NewsDBHandler;
import com.pastelloid.vijay.jds.news.NewsFragment;
import com.pastelloid.vijay.jds.notification.MessageFragment;
import com.pastelloid.vijay.jds.profile.ProfileFragment;

import java.io.IOException;
import java.lang.reflect.Method;


public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private SectionsPagerAdapter mSectionsPagerAdapter;
    private ViewPager mViewPager;
    private SharedPreferences sharedPrefs;
    private TextView drawerUsername;
    private TextView drawerEmail;
    private View navHeader;

    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drawer);

        sharedPrefs=getSharedPreferences("com.pastelloid.vijay.jds.login",MODE_PRIVATE);

        FirebaseMessaging.getInstance().subscribeToTopic("JDS");
       String token =FirebaseInstanceId.getInstance().getToken();

        Log.d("Android","Android Token:"+token);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());

        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) findViewById(R.id.container);
        mViewPager.setAdapter(mSectionsPagerAdapter);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(mViewPager);




        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        NavigationView navView=(NavigationView)findViewById(R.id.nav_view);

        navHeader=navView.getHeaderView(0);
        drawerUsername=(TextView)navHeader.findViewById(R.id.drawerUsername);

        drawerUsername.setText(sharedPrefs.getString("username","Unknown"));

        drawerEmail=(TextView)navHeader.findViewById(R.id.drawerEmail);
        drawerEmail.setText(sharedPrefs.getString("email","Unknown"));

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);


        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            //Toast.makeText(this,"Logout",Toast.LENGTH_SHORT).show();
           /*
            SharedPreferences.Editor editor=sharedPrefs.edit();
            editor.clear();
            editor.commit();

            */

           // RequestQueue requestQueue= Volley.newRequestQueue(this);
            /*
            if ( requestQueue!= null) {
                requestQueue.cancelAll("jdsSession");
            }
            */

            Intent startMain = new Intent(Intent.ACTION_MAIN);
            startMain.addCategory(Intent.CATEGORY_HOME);
            startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(startMain);
            finish();
            return true;
        }else if(id==R.id.action_share){
            Intent shareIntent=new Intent(Intent.ACTION_SEND);
            shareIntent.setAction(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_TEXT,"Visit Us : http://pastelloid.com/jds");
            startActivity(Intent.createChooser(shareIntent, "Share!"));

        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_aboutjds) {
            // Handle the About JDS action
            Intent i=new Intent(this, DrawerAboutJDS.class);
            startActivity(i);
        } else if (id == R.id.nav_leadership) {
            //Handle Our Leadership action
            Intent i=new Intent(this,DrawerOurLeadership.class);
            startActivity(i);
        } else if (id == R.id.nav_electedmembers) {
            //Handle Elected Members
            Intent i=new Intent(this, DrawerElectedMembers.class);
            startActivity(i);
        } else if (id == R.id.nav_manifestos) {
            Intent i=new Intent(this, DrawerManifestos.class);
            startActivity(i);
        } else if (id == R.id.nav_mediacenter) {
            Intent i=new Intent(this, DrawerMediaCenter.class);
            startActivity(i);
        } else if (id == R.id.nav_contribution) {
            Intent i=new Intent(this, DrawerContribution.class);
            startActivity(i);

        }else if(id==R.id.nav_settings){
            Intent i=new Intent(this, DrawerSettings.class);
            startActivity(i);
        }
        else if(id==R.id.nav_about){
            Intent i=new Intent(this, DrawerInfo.class);
            startActivity(i);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    public Action getIndexApiAction() {
        Thing object = new Thing.Builder()
                .setName("Main Page") // TODO: Define a title for the content shown.
                // TODO: Make sure this auto-generated URL is correct.
                .setUrl(Uri.parse("http://[ENTER-YOUR-URL-HERE]"))
                .build();
        return new Action.Builder(Action.TYPE_VIEW)
                .setObject(object)
                .setActionStatus(Action.STATUS_TYPE_COMPLETED)
                .build();
    }

    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        AppIndex.AppIndexApi.start(client, getIndexApiAction());
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        AppIndex.AppIndexApi.end(client, getIndexApiAction());
        client.disconnect();
        super.onStop();

    }

    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            // getItem is called to instantiate the fragment for the given page.
            // Return a PlaceholderFragment (defined as a static inner class below).


            switch (position) {
                case 0:
                    return NewsFragment.newInstance(position + 1);
                case 1:
                    return FaceboookFragment.newInstance(position + 1);
                case 3:
                    return ProfileFragment.newInstance(position + 1);
                case 2:
                    return MessageFragment.newInstance(position + 1);

                //default: return PlaceholderFragment.newInstance(position + 1);
            }
            return null;

        }

        @Override
        public int getCount() {
            // Show 3 total pages.
            return 4;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0:
                    return "News";
                case 1:
                    return "Facebook Timeline";
                case 2:
                    return "Notifications";
                case 3:
                    return "Profile";
            }
            return null;
        }
    }
}
