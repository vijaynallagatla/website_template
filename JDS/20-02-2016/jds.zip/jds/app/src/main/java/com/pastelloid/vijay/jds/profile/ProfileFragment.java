package com.pastelloid.vijay.jds.profile;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.pastelloid.vijay.jds.R;


public class ProfileFragment extends Fragment {

    private String username;
    private String gender;
    private String email;
    private String constituency;
    private String contact_no;

    public ProfileFragment() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static ProfileFragment newInstance(int position) {
        ProfileFragment fragment = new ProfileFragment();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_profile, container, false);

        TextView textView_username=(TextView)view.findViewById(R.id.jdsUserName);
        TextView textView_email=(TextView)view.findViewById(R.id.profile_email);
        TextView textView_contact_no=(TextView)view.findViewById(R.id.profile_contactNo);
        TextView textView_constituency=(TextView)view.findViewById(R.id.profile_constituency);



        SharedPreferences prefs= getActivity().getSharedPreferences("com.pastelloid.vijay.jds.login",Context.MODE_PRIVATE);
        username=prefs.getString("username","Unknown");
        email=prefs.getString("email","abc@abc.com");
        contact_no=prefs.getString("phno","+919876543210");
        constituency=prefs.getString("constituency","Unknown");

        textView_constituency.setText(constituency);
        textView_username.setText(username);
        textView_email.setText(email);
        textView_contact_no.setText(contact_no);
        return view;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();

    }
}
