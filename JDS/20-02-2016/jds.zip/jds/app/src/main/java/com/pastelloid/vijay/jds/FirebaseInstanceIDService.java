package com.pastelloid.vijay.jds;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;
import com.pastelloid.vijay.jds.MainActivity;
import com.pastelloid.vijay.jds.R;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

/**
 * Created by VN045584 on 9/26/2016.
 */
public class FirebaseInstanceIDService extends FirebaseInstanceIdService {

    private RequestQueue requestQueue;
    private static String URL;
    private StringRequest stringRequest;
    @Override
    public void onTokenRefresh() {
        String str= FirebaseInstanceId.getInstance().getToken();
        registerToken(str);
        Log.d("Token",str);


    }

    public void registerToken(String token){
        URL=getString(R.string.host_url);
        URL+="user_deviceid.php";
        SharedPreferences prefs = getSharedPreferences("com.pastelloid.vijay.jds.login", MODE_PRIVATE);

        OkHttpClient client=new OkHttpClient();
        RequestBody body=new FormBody.Builder()
                .add("email",prefs.getString("email","unknown"))
                .add("deviceid",token)
                .build();

        Request request=new Request.Builder()
                .url(URL)
                .post(body)
                .build();

        try{
            client.newCall(request).execute();

        }catch (Exception ex){
                ex.printStackTrace();
        }

        Log.d("Token:",token);
        Intent i=new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
    }

    @Override
    public String getPackageName() {
        Log.d("PackageName", super.getPackageName());
        return super.getPackageName();
    }
}
