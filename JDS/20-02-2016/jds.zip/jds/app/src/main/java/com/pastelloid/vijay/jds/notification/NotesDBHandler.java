package com.pastelloid.vijay.jds.notification;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by vn045584 on 10/14/2016.
 */

public class NotesDBHandler extends SQLiteOpenHelper {

    public static final String DATABASE_NAME="jds";
    public static final String TABLE_NAME="notes";
    public static final String ID="id";
    public static final String PUBDATE="pubdate";
    public static final String PUBTIME="pubtime";
    public static final String TITLE="title";
    public static final String URL="URL";
    public static final String BODY="body";

    public NotesDBHandler(Context context) {
        super(context, DATABASE_NAME, null, 1);
        SQLiteDatabase db=this.getWritableDatabase();
        //onCreate(db);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            final String table = "CREATE TABLE notes(ID INTEGER PRIMARY KEY,PUBDATE TEXT,PUBTIME TEXT,TITLE TEXT,URL TEXT,BODY TEXT);";
            db.execSQL(table);
        }catch (Exception ex){
            Log.d("SQLCreate","Error in creating table ");
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db=this.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        //onCreate(db);
    }

    public boolean insertNews(int id,String pubDate,String pubTime,String title,String url,String body ){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put(ID,id);
        values.put(PUBDATE,pubDate);
        values.put(PUBTIME,pubTime);
        values.put(TITLE,title);
        values.put(URL,url);
        values.put(BODY,body);
        long result=db.insert(TABLE_NAME,null,values);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }

    public Cursor getAllData(){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor result=db.rawQuery("SELECT * FROM notes ORDER BY ID ASC",null);
        return result;
    }
    public long getNewsCount(){
        SQLiteDatabase db=this.getReadableDatabase();
        long count = DatabaseUtils.longForQuery(db, "SELECT COUNT(ID) FROM notes", null);
        return count;
    }
}
