package com.pastelloid.vijay.jds;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.RingtoneManager;
import android.net.Uri;
import android.support.v7.app.NotificationCompat;
import android.support.v7.app.NotificationCompat.Builder;
import android.util.Log;
import android.widget.Toast;

import com.google.firebase.messaging.RemoteMessage;
import com.pastelloid.vijay.jds.MainActivity;
import com.pastelloid.vijay.jds.R;
import com.pastelloid.vijay.jds.notification.NotesDBHandler;

import java.text.SimpleDateFormat;
import java.util.Calendar;


/**
 * Created by VN045584 on 9/26/2016.
 */
public class FirebaseMessagingService extends com.google.firebase.messaging.FirebaseMessagingService {
    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        showNotification(remoteMessage.getData().get("title"),remoteMessage.getData().get("message"));
        Log.d("FCM","Message:"+remoteMessage.getData().get("title"));
    }

    public void showNotification(String title,String message){
        Intent i=new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);


        PendingIntent pendingIntent=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_UPDATE_CURRENT);
        Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
      android.support.v4.app.NotificationCompat.Builder builder=new android.support.v4.app.NotificationCompat.Builder(this)
              .setAutoCancel(true)
              .setContentTitle(title)
              .setContentText(message)
              .setSmallIcon(R.drawable.ic_leadership)
              .setSound(alarmSound)
              .setVibrate(new long[]{1000,1000})
              .setContentIntent(pendingIntent);


        NotificationManager manager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        manager.notify(0,builder.build());

        NotesDBHandler db=new NotesDBHandler(this);
        long id=db.getNewsCount();
        int j= (int) id+1;
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat mdformat = new SimpleDateFormat("dd / MM / yyyy ");
        String strDate = mdformat.format(calendar.getTime());
        if (db.insertNews(j, strDate, "10:00 AM", title,"URL", message))
            Log.d("News_Data_Insert", "Success");
        else
            Log.d("News_Data_Insert", "Failure");

    }
}
