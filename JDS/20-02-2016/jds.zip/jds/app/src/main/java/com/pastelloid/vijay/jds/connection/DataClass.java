package com.pastelloid.vijay.jds.connection;

/**
 * Created by vn045584 on 10/13/2016.
 */

public class DataClass {

    DataClass(){

    }

}
