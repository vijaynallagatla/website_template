package com.pastelloid.vijay.jds.notification;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.pastelloid.vijay.jds.R;
import com.pastelloid.vijay.jds.news.NewsDBHandler;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class MessageFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match

    public NotesDBHandler notesDBHandler;
    public RecyclerView recyclerView;
    public RecyclerView.LayoutManager layoutManager;
    public RecyclerView.Adapter adapter;

    public MessageFragment() {
        // Required empty public constructor
    }

 // this fragment using the provided parameters.

    // TODO: Rename and change types and number of parameters
    public static MessageFragment newInstance(int position) {
        MessageFragment fragment = new MessageFragment();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        notesDBHandler=new NotesDBHandler(this.getContext());
        long newsCount=notesDBHandler.getNewsCount();
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat mdformat = new SimpleDateFormat("dd / MM / yyyy ");
        String strDate = mdformat.format(calendar.getTime());
        if(newsCount==0) {

            if (notesDBHandler.insertNews(1, strDate, "10:00 AM", "Hello There!", "http://pastelloid.com/jds/", "Welcome to Janata Dal(Secular)"))
                Log.d("News_Data_Insert", "Success");
            else
                Log.d("News_Data_Insert", "Failure");
        }else {
            Log.d("News_Data_Insert", "From Website");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =inflater.inflate(R.layout.fragment_message, container, false);

        databaseCards(view);
        checkOnlineNews();
        return view;

    }

    public void databaseCards(View view){
        recyclerView=(RecyclerView)view.findViewById(R.id.notes_recycler_view);

        layoutManager=new LinearLayoutManager(this.getContext());
        recyclerView.setLayoutManager(layoutManager);

        NotesDBHandler db=new NotesDBHandler(this.getContext());
        long newsCount=db.getNewsCount();
        Cursor cursor=db.getAllData();

        cursor.moveToFirst();

        ArrayList<String> titles = new ArrayList<String>();
        ArrayList<String> url = new ArrayList<String>();
        ArrayList<String> body = new ArrayList<String>();
        while(!cursor.isAfterLast()) {
            titles.add(cursor.getString(3)+"\n");
            url.add(cursor.getString(4));
            body.add(cursor.getString(5));
            cursor.moveToNext();
        }
        cursor.close();
        String[] title= titles.toArray(new String[titles.size()]);
        String[] uri=url.toArray(new String[url.size()]);
        String[] content=body.toArray(new String[body.size()]);

        adapter=new NotesRecyclerAdapter(title,uri,content);
        recyclerView.setAdapter(adapter);
    }

    public void checkOnlineNews(){

    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();

    }

}
