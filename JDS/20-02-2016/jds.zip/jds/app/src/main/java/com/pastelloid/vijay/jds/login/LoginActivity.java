package com.pastelloid.vijay.jds.login;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.appindexing.Thing;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.firebase.iid.FirebaseInstanceId;
import com.pastelloid.vijay.jds.FirebaseInstanceIDService;
import com.pastelloid.vijay.jds.connection.No_Internet;
import com.pastelloid.vijay.jds.MainActivity;
import com.pastelloid.vijay.jds.R;
import com.pastelloid.vijay.jds.Registration;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;

public class LoginActivity extends AppCompatActivity {
    // UI references.
    private EditText mEmailView;
    private EditText mUname;
    private View mProgressView;
    private View mLoginFormView;
    private EditText mPhNo;
    private No_Internet internetConnection;
    private RequestQueue requestQueue;
    private static String URL;
    private StringRequest stringRequest;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        internetConnection = new No_Internet();

        URL=getString(R.string.host_url);
        URL+="user_registration.php";

        SharedPreferences prefs = getSharedPreferences("com.pastelloid.vijay.jds.login", MODE_PRIVATE);
        String login_state = prefs.getString("login_state", "false");
        if (login_state.equals("true")) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        } else {
            setContentView(R.layout.activity_login);

            // Set up the login form
            mEmailView = (EditText)findViewById(R.id.emailID);
            mUname = (AutoCompleteTextView) findViewById(R.id.Uname);
            mPhNo=(EditText) findViewById(R.id.phNo);
            requestQueue = Volley.newRequestQueue(this);
        }
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
       client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }


    /**
     * Attempts to sign in or register the account specified by the login form.
     * If there are form errors (invalid email, missing fields, etc.), the
     * errors are presented and no actual login attempt is made.
     */
    public void attemptLogin(View view) {
        //stringRequest.setTag("jdsSession");
        // Simulate network access.
        String email = mEmailView.getText().toString();
        String uname = mUname.getText().toString();
        stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject json = new JSONObject(response);
                    //Toast.makeText(getApplicationContext(),"State : "+json.getString("login_state"),Toast.LENGTH_SHORT).show();
                    String state = json.getString("reg_state");
                    if (state.equals("success")) {
                        //Toast.makeText(getApplicationContext(), "welcome", Toast.LENGTH_SHORT).show();
                        SharedPreferences sharedPref = getSharedPreferences("com.pastelloid.vijay.jds.login", Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPref.edit();
                        editor.putString("login_state", "true");
                        editor.putString("email", mEmailView.getText().toString());
                        // Toast.makeText(getApplicationContext(),"We are entered to OnResponse State",Toast.LENGTH_SHORT).show();
                        editor.putString("username", json.getString("username"));
                        editor.putString("phno", json.getString("phno"));
                        editor.putString("constituency", json.getString("constituency"));
                        editor.commit();
                        registerToken(FirebaseInstanceId.getInstance().getToken());
                        startActivity(new Intent(getApplicationContext(), MainActivity.class));


                        finish();
                    } else {
                        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                        Toast.makeText(getApplicationContext(), "Enter valid Details", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "Error Response : "+error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<String, String>();
                hashMap.put("email", mEmailView.getText().toString());
                hashMap.put("phno", mPhNo.getText().toString());
                hashMap.put("name", mUname.getText().toString());
                hashMap.put("constituency","Bengaluru South");
                return hashMap;
            }
        };
        requestQueue.add(stringRequest);
    }

    private boolean isEmailValid(String email) {
        //TODO: Replace this with your own logic
        return email.contains("@");
    }

    private boolean isPasswordValid(String password) {
        //TODO: Replace this with your own logic
        return password.length() > 4;
    }

    public void registerToJDS(View view) {
        startActivity(new Intent(getApplicationContext(), Registration.class));
    }

    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    public Action getIndexApiAction() {
        Thing object = new Thing.Builder()
                .setName("Login Page") // TODO: Define a title for the content shown.
                // TODO: Make sure this auto-generated URL is correct.
                .setUrl(Uri.parse("http://[ENTER-YOUR-URL-HERE]"))
                .build();
        return new Action.Builder(Action.TYPE_VIEW)
                .setObject(object)
                .setActionStatus(Action.STATUS_TYPE_COMPLETED)
                .build();
    }

    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        AppIndex.AppIndexApi.start(client, getIndexApiAction());
    }

    public void registerToken(final String token){
        URL=getString(R.string.host_url);
        URL+="user_deviceid.php";
        final SharedPreferences prefs = getSharedPreferences("com.pastelloid.vijay.jds.login", MODE_PRIVATE);

        stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject json = new JSONObject(response);

                    String state = json.getString("reg_state");
                    if (state.equals("success")) {
                       Log.d("TokenChanged: ",token);

                    } else {
                        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                        Toast.makeText(getApplicationContext(), "Enter valid email and password" + json.getString("login_state"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "Error Response : "+error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<String, String>();
                hashMap.put("email", prefs.getString("email","unknown"));
                hashMap.put("deviceid", token);
                return hashMap;
            }
        };
        requestQueue.add(stringRequest);
        Log.d("Token:",token);
        Intent i=new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        AppIndex.AppIndexApi.end(client, getIndexApiAction());
        client.disconnect();
    }
}

