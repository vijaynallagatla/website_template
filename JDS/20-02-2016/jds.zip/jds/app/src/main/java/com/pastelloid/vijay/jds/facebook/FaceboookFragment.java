package com.pastelloid.vijay.jds.facebook;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.pastelloid.vijay.jds.R;

public class FaceboookFragment extends Fragment {


    public FaceboookFragment() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static FaceboookFragment newInstance(int postion) {
        FaceboookFragment fragment = new FaceboookFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =inflater.inflate(R.layout.fragment_faceboook, container, false);
        final WebView fbWebView=(WebView) view.findViewById(R.id.fbWebView);
        WebSettings webSettings = fbWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        fbWebView.setWebViewClient(new WebViewClient()
        {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url)
            {
                fbWebView.loadUrl(url);
                return true;
            }
        });
        fbWebView.loadUrl("http://pastelloid.com/jds/android/fb.php");
        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();

    }
}
