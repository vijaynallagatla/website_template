package com.pastelloid.vijay.jds.news;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by vn045584 on 10/13/2016.
 */

public class NewsDBHandler extends SQLiteOpenHelper {

    public static final String DATABASE_NAME="jds";
    public static final String TABLE_NAME="news";
    public static final String ID="id";
    public static final String PUBDATE="pubdate";
    public static final String PUBTIME="pubtime";
    public static final String TITLE="title";
    public static final String IMAGE="IMAGE";
    public static final String BODY="body";

    public NewsDBHandler(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE notes(ID INTEGER PRIMARY KEY,PUBDATE TEXT,PUBTIME TEXT,TITLE TEXT,URL TEXT,BODY TEXT)");
        db.execSQL("CREATE TABLE "+TABLE_NAME+"(ID INTEGER PRIMARY KEY,PUBDATE TEXT,PUBTIME TEXT,TITLE TEXT,IMAGE TEXT,BODY TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS notification");
    }

    public boolean insertNews(int id,String pubDate,String pubTime,String title,String body,String img){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put(ID,id);
        values.put(PUBDATE,pubDate);
        values.put(PUBTIME,pubTime);
        values.put(TITLE,title);
        values.put(IMAGE,img);
        values.put(BODY,body);
        long result=db.insert(TABLE_NAME,null,values);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }

    public Cursor getAllData(){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor result=db.rawQuery("SELECT * FROM "+TABLE_NAME+" ORDER BY ID DESC",null);
        return result;
    }

    public int getLastID(){
        SQLiteDatabase db=this.getWritableDatabase();
        long id=0;
        try {
           id= DatabaseUtils.longForQuery(db, "SELECT ID FROM " + TABLE_NAME + " ORDER BY ID DESC LIMIT 1", null);
       }catch (Exception ex){
            //Log.d("SQLException",ex.getMessage());
       }
        return (int)id;
    }
    public long getNewsCount(){
        SQLiteDatabase db=this.getWritableDatabase();
        long count = DatabaseUtils.longForQuery(db, "SELECT COUNT(ID) FROM "+TABLE_NAME, null);
        return count;
    }
}
